
import numpy as np
from sklearn.linear_model import Ridge

class Calibrator:
    def __init__(self, alpha: float=1.0):
        self.model = Ridge(alpha=alpha)
        self.is_fit = False

    def fit(self, X: np.ndarray, y: np.ndarray):
        self.model.fit(X, y)
        self.is_fit = True

    def predict(self, X: np.ndarray) -> np.ndarray:
        if not self.is_fit:
            # For demo, fit a dummy identity target using the first call features
            y = np.array([1.0]*len(X))
            self.fit(X, y)
        return self.model.predict(X)
