
from typing import List, Optional
import numpy as np
import cv2

def _synthetic_strip(width=640, height=240):
    # Create a synthetic test strip with three pads
    img = np.ones((height, width, 3), dtype=np.uint8) * 180
    cv2.rectangle(img, (60, 60), (180, 180), (90, 160, 220), -1)   # bluish pad
    cv2.rectangle(img, (240, 60), (360, 180), (120, 220, 110), -1) # greenish pad
    cv2.rectangle(img, (420, 60), (540, 180), (220, 140, 90), -1)  # brownish pad
    # Add mild vignette
    k = cv2.getGaussianKernel(width, width//2) @ cv2.getGaussianKernel(height, height//2).T
    k = k / k.max()
    img = (img.astype(np.float32) * (0.7 + 0.3*k.T[...,None])).clip(0,255).astype(np.uint8)
    return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

def capture_burst(path: Optional[str], fps:int=2, seconds:int=3) -> List[np.ndarray]:
    if path:
        img = cv2.imread(path, cv2.IMREAD_COLOR)
        if img is None:
            raise FileNotFoundError(path)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    else:
        img = _synthetic_strip()
    # Simulate a small burst by jittering brightness
    burst = []
    for i in range(max(1, fps*seconds)):
        scale = 0.9 + 0.02*i
        frame = (img.astype(np.float32)*scale).clip(0,255).astype(np.uint8)
        burst.append(frame)
    return burst
