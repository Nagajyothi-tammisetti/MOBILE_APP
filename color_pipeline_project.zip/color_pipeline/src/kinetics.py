
import numpy as np

def fit_slope(y: np.ndarray):
    x = np.arange(len(y))
    A = np.vstack([x, np.ones_like(x)]).T
    m, b = np.linalg.lstsq(A, y, rcond=None)[0]
    return m, b

def fit_plateau(y: np.ndarray):
    return float(np.mean(y))

def choose_model(time_series: np.ndarray):
    # Very small demo logic: prefer slope if variance decreases strongly
    m, b = fit_slope(time_series)
    plateau = fit_plateau(time_series)
    return {"model": "slope", "slope": m, "intercept": b, "plateau": plateau}
