
import numpy as np
from .color_constancy import chromatic_features

def extract_features(img_roi: np.ndarray) -> np.ndarray:
    # Aggregate color stats + chromaticity + OD moments
    ch = chromatic_features(img_roi)
    vecs = []
    for k in ["rg","gb","od"]:
        v = ch[k].reshape(-1)
        vecs.extend([v.mean(), v.std()])
    # Add raw RGB moments
    v = img_roi.reshape(-1, 3)
    vecs.extend(v.mean(axis=0).tolist())
    vecs.extend(v.std(axis=0).tolist())
    return np.array(vecs, dtype=np.float32)
