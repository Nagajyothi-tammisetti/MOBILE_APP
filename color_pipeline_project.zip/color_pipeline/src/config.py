
from dataclasses import dataclass

@dataclass
class Config:
    # Capture
    burst_fps: int = 2
    burst_seconds: int = 3
    # Linearization
    intensity_min: float = 0.0
    intensity_max: float = 1.0
    # ROI
    roi_mode: str = "center"     # center | full | box:x1,y1,x2,y2
    roi_center_frac: float = 0.5 # central box size fraction
    # Interference
    tukey_k: float = 1.5
    saturation_thresh: float = 0.98
    # Kinetics
    use_slope_window_secs: tuple = (10, 40)
    use_plateau_window_secs: tuple = (60, 90)
    # Calibration/ML
    ridge_alpha: float = 1.0
    # QC
    bootstraps: int = 100
    deltaE_fail: float = 3.0
    roi_nonuniformity_fail: float = 0.2  # std/mean
