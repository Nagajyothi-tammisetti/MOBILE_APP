
import numpy as np

def central_roi(img: np.ndarray, frac: float=0.5) -> np.ndarray:
    h, w = img.shape[:2]
    dh, dw = int(h*frac/2), int(w*frac/2)
    cy, cx = h//2, w//2
    return img[cy-dh:cy+dh, cx-dw:cx+dw]

def to_feature_vector(roi: np.ndarray) -> np.ndarray:
    # Pool central pixels: mean, std of each channel
    mean = roi.reshape(-1, roi.shape[-1]).mean(axis=0)
    std = roi.reshape(-1, roi.shape[-1]).std(axis=0)
    return np.concatenate([mean, std], axis=0)
