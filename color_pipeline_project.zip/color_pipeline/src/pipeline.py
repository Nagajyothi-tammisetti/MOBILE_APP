
import numpy as np
from .config import Config
from . import capture, linearization, color_constancy, roi, interference, kinetics, features, calibration, qc

def run_pipeline(image_path=None, visualize=False):
    cfg = Config()

    # 1) Capture
    burst = capture.capture_burst(image_path, cfg.burst_fps, cfg.burst_seconds)
    # Use first frame for demo
    frame = burst[0]

    # 2) Linearization
    lin = linearization.linearize(frame)

    # 3) Color constancy
    bal = color_constancy.gray_world(lin)

    # 4) ROI
    crop = roi.central_roi(bal, cfg.roi_center_frac)

    # 5) Interference handling (masks)
    mask1 = interference.mask_specular(crop, cfg.saturation_thresh)
    crop_masked = crop[mask1]
    if crop_masked.size == 0:  # fallback
        crop_masked = crop.reshape(-1,3)
    roi_nonuniformity = crop.reshape(-1,3).std()/ (crop.reshape(-1,3).mean()+1e-6)

    # 6) Kinetics (demo with synthetic series derived from mean intensity over burst)
    series = []
    for f in burst:
        l = linearization.linearize(f)
        b = color_constancy.gray_world(l)
        c = roi.central_roi(b, cfg.roi_center_frac)
        series.append(c.mean())
    series = np.array(series, dtype=np.float32)
    kin = kinetics.choose_model(series)

    # 7) Features + Calibration/ML
    X = features.extract_features(crop)
    X = X.reshape(1, -1)
    cal = calibration.Calibrator(alpha=cfg.ridge_alpha)
    y_pred = cal.predict(X)

    # 8) Uncertainty + QC
    mean_pred, ci = qc.bootstrap_ci(cal, X, n_boot=cfg.bootstraps)
    # Dummy ΔE from ref patch (simulate small value)
    deltaE = float(abs(bal.mean() - 0.5)*10)
    qc_ok, reasons = qc.qc_checks(deltaE, float(roi_nonuniformity), cfg.deltaE_fail, cfg.roi_nonuniformity_fail)

    return {
        "value": float(mean_pred[0]),
        "units": "a.u.",
        "range_flag": "normal",
        "ci_95": float(ci[0]),
        "qc_ok": bool(qc_ok),
        "qc_reasons": reasons,
        "kinetics": kin,
        "debug": {
            "series_len": int(len(series)),
            "roi_nonuniformity": float(roi_nonuniformity),
            "deltaE_sim": float(deltaE)
        }
    }
