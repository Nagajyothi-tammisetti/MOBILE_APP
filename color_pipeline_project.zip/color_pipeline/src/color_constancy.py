
import numpy as np

def gray_world(img: np.ndarray) -> np.ndarray:
    # Simple Retinex-like gray-world balancing
    avg = np.mean(img, axis=(0,1)) + 1e-8
    balanced = img / avg
    return np.clip(balanced / balanced.max(), 0, 1)

def chromatic_features(img: np.ndarray) -> dict:
    # Physics-ish chromaticity and optical density (relative to unit white)
    eps = 1e-6
    R,G,B = [img[...,i].astype(np.float32)+eps for i in range(3)]
    rg = R/(G+eps)
    gb = G/(B+eps)
    od = -np.log10((R+G+B)/3.0 + eps)  # toy OD
    return {
        "rg": rg, "gb": gb, "od": od
    }
