
import numpy as np
from sklearn.utils import resample

def bootstrap_ci(model, X: np.ndarray, n_boot: int=100, alpha: float=0.05):
    preds = []
    n = len(X)
    for _ in range(n_boot):
        idx = np.random.randint(0, n, n)
        Xb = X[idx]
        preds.append(model.predict(Xb))
    preds = np.array(preds)  # [B, n]
    mean_pred = preds.mean(axis=0)
    ci = 1.96 * preds.std(axis=0)  # approx 95% CI
    return mean_pred, ci

def qc_checks(reference_deltaE: float, roi_nonuniformity: float, deltaE_fail: float=3.0, nonuni_fail: float=0.2):
    reasons = []
    ok = True
    if reference_deltaE > deltaE_fail:
        ok = False; reasons.append(f"Reference ΔE {reference_deltaE:.2f} > {deltaE_fail}")
    if roi_nonuniformity > nonuni_fail:
        ok = False; reasons.append(f"ROI non-uniformity {roi_nonuniformity:.2f} > {nonuni_fail}")
    return ok, reasons
