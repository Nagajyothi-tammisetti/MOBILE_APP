
import numpy as np
from skimage import exposure

def linearize(img: np.ndarray) -> np.ndarray:
    # Convert 8-bit RGB to [0,1] float and rescale intensities (flat-field placeholder)
    f = img.astype(np.float32)/255.0
    f = exposure.rescale_intensity(f, out_range=(0,1))
    return f
