
import numpy as np

def tukey_fence_reject(x: np.ndarray, k: float=1.5):
    # x is 1-D array (e.g., intensities). Return mask of inliers.
    q1, q3 = np.percentile(x, [25, 75])
    iqr = q3 - q1
    lo, hi = q1 - k*iqr, q3 + k*iqr
    return (x >= lo) & (x <= hi)

def mask_specular(img: np.ndarray, saturation_thresh: float=0.98):
    # Mask pixels near white as specular highlights
    val = img.max(axis=-1)
    return val < saturation_thresh
